﻿using Microsoft.AspNetCore.Mvc;

namespace Test1.Areas.User1.Controllers
{
    [Area("User1")]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Page1()
        {
            return View();
        }

        public IActionResult Page2()
        {
            return View();
        }

        public IActionResult Page3()
        {
            return View();
        }
    }
}
